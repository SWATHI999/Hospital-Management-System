<?php
session_start();
?>
 <?php
  $conn = mysqli_connect("localhost", "root",
    "1234", "HMS")
    or die("Cannot connect to database:" .
    mysqli_connect_error($conn));
$c1=$_POST['dnamel'];
$c2=$_POST['cdl'];
$s3=$_SESSION['uemail'];
$_SESSION['s']=$c1;
echo $s3;

$result = mysqli_query($conn,"select * from DOCTOR d where d.name='$c1'");

while($row = mysqli_fetch_array($result))
{
$x=$row['id'];
}

$result1 = mysqli_query($conn,"select * from users u where u.email='$s3'");

while($row1 = mysqli_fetch_array($result1))
{
$x1=$row1['phone_number'];
$x2=$row1['name'];
}



#echo "<center><h3> $c1 </h3></center>";

$result1 = mysqli_query($conn,"insert into bookings(doctor_id,user_name,date_of_consultation,phone_number,fee_status ) values('$x','$x2','$c2','$x1','NO')");
$m="Your will be intimated soon about the consultation!";
            echo "<script type='text/javascript'>alert('$m');</script>";

mysqli_close($conn);
?>
<html>
<center>
<br>
<br>
<h3><i><b><u>PAY CONSULTATION FEE</u></b></i></h3>
<br>
<body>
<a href="db2newlaterfee.php">Pay here</a>
</body>
</center>
</html>
