<html>
<head>
<title>
Give Details
</title>
</head>
<center><h3><i><b>FILL THE FORM</b></i></h3></center>

<form action="db2cannotchange.php" method="post">

<center>
<INPUT type = "text" name="dname" placeholder="Enter name" required><br><br>
<INPUT type = "text" name="dsp" placeholder="Enter Specialization" required><br><br>


<INPUT type = "text" name="dexp" placeholder="Enter Experience" required><br><br>
<INPUT type = "text" name="frt" placeholder="Enter From Timings" required><br><br>
<INPUT type = "text" name="tot" placeholder="Enter To Timings" required><br><br>
<INPUT type = "text" name="dc"  placeholder="Enter Fee" required><br><br>
<INPUT type = "Submit" name = "Submit1" value = "Submit">
</center>

</form>

</html>
