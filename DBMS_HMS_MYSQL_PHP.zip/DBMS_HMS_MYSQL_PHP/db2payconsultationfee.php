<html>
<head>
<title>
Give Details
</title>
</head>
<center><h3><i><b>APPOINTMENT BOOKING</b></i></h3></center>

<form action="db2consultationfeetransaction.php" method='post'>

<center>
DOCTOR NAME:<INPUT type = "text" name="dname" placeholder="Enter" required><br><br>
CONSULTATION DATE:<INPUT type = "date" name="cd" required><br><br>
 PAY:
  <input type="radio" name="ul" value="NOW" checked>NOW
  <input type="radio" name="ul" value="LATER">LATER
 
  <br><br>

<?php
echo "$ul";
$x="NOW";

if ($fetch['ul']==$x)
{
echo "<input type='text' name='uac' placeholder='Account Number'>";
}
?>

<INPUT type = "Submit" name = "Submit1" value = "Submit">
</center>
</form>
</html>
