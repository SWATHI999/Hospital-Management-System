
<?php
$servername = "localhost";
$username = "root";
$password = "1234";
$dbname = "HMS";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$s1=$_POST['uname'];
$s2=$_POST['uage'];
$s3=$_POST['ugender'];
$s4=$_POST['uemail'];
$s5=$_POST['upwd'];
$s6=$_POST['uad'];
$s7=$_POST['uph'];
#$_SESSION['uemail']=$_POST['uemail'];
#echo '$_SESSION['uemail']';

$result = mysqli_query($conn,"insert into users(name,age,gender,email,password,address,phone_number) values('$s1','$s2','$s3','$s4','$s5','$s6','$s7')");
mysqli_close($con);
?>
<html>
<body>
<center>
<h3><b><i>OUR SERVICES</i></b></h3></center>
<center>
<a href="db2userconsultation.php">FIND A DOCTOR</a><br><br>
<a href="db2usermedicine.php">BUY MEDICINES</a><br><br>
<a href="db2viewalldoctors.php">VIEW ALL DOCTORS</a><br><br>
 </center></body></html>

<html>
<style type="text/css">
.topright{
position:absolute;
top:5px;
right:5px;
}
</style>
<div class="topright">
<form action="db2homepage.php" >
    <input type="submit" value="LOGOUT" style="float: bottom;"/>
</form>
</div>
</html>
