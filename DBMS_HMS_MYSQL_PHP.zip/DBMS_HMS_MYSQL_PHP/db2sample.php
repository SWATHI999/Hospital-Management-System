<?php
session_start();
?>

<?php
  $conn = mysqli_connect("localhost", "root",
    "1234", "HMS")
    or die("Cannot connect to database:" .
    mysqli_connect_error($conn));
echo $_SESSION['x'];
$d=$_SESSION['x'];

if(!empty($_POST['password']) && !empty($_POST['email']))
{
    $email = $_POST['email'];
    $password = $_POST['password'];
    



    $sql = "SELECT * FROM head WHERE password = '$password' AND email = '$email' and dept_name='$d' ";
    $result = mysqli_query($conn,$sql);

        if(mysqli_num_rows($result)==1)
        { 
	    $m="Successfully Authenticated!";
            echo "<script type='text/javascript'>alert('$m');window.location.href='';</script>";
	}
      else 
	{
	     $m1="Authentication Failed!";
            echo "<script type='text/javascript'>alert('$m1');window.location.href='';</script>";
	}
}

?>
<html>
<head>
<body>
<center>
<a href="db2dhcon.php">DOCTOR CONSULTATION FEE</a><br><br>
<a href="db2dhdoctimup1.php">DOCTOR CONSULTATION TIMINGS</a><br><br>
</center>
</body>
<head>
</html>







