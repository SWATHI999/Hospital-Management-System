<?php
session_start();
?>
<?php
$servername = "localhost";
$username = "root";
$password = "1234";
$dbname = "HMS";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$x=$_SESSION['x'];
//echo "$x";
$x1=$_POST['dhup'];
$x2=$_SESSION['x1'];
//echo "$x1";
//echo "$x2";
$result1 = mysqli_query($conn,"call update_consultation_fee('$x','$x2','$x1')");
?>
