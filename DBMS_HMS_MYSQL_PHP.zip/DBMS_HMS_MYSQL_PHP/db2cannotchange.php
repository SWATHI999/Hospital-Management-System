<?php
$servername = "localhost";
$username = "root";
$password = "1234";
$dbname = "HMS";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$x=$_POST['dname'];
$x1=$_POST['dsp'];
$x2=$_POST['dexp'];
$x3=$_POST['frt'];
$x4=$_POST['tot'];
$x5=$_POST['dc'];

$result = mysqli_query($conn,"call cannot_change('$x','$x1','$x2','$x3','$x4','$x5')");

echo "<center><h3>Available DOCTORS </h3></center>";

echo "<table border='1'>
<tr>
<th>Doctor Name</th>
<th>Specialization</th>
<th>Experience</th>
<th>From Timings</th>
<th>To Timings</th>
<th>Consultation Fee</th>

</tr>";
while($row = mysqli_fetch_array($result))
{
echo "<tr>";

echo "<td>" . $row['name'] . "</td>";
echo "<td>" . $row['specialization'] . "</td>";
echo "<td>" . $row['experience'] . "</td>";
echo "<td>" . $row['from_timings'] . "</td>";
echo "<td>" . $row['to_timings'] . "</td>";
echo "<td>" . $row['consultation_fee'] . "</td>";

echo "</tr>";
}
echo "</table>";
$conn->close();
?>





