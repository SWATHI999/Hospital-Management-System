<!--<?php
session_start();
?>-->

<?php
  $conn = mysqli_connect("localhost", "root",
    "1234", "HMS")
    or die("Cannot connect to database:" .
    mysqli_connect_error($conn));

if(!empty($_POST['password']) && !empty($_POST['email']))
{
     $email = "sonia@gmail.com";
    $password = "sonia";
     $st=0;
    if($password==$_POST['password'] and $email==$_POST['email'])
     {
		$st=1;
     }
  else
{
	$st=0;
}
   
    #$_SESSION['uemail']=$_POST['email'];
     #print_r($_SESSION);



   // $sql = "SELECT * FROM transactions WHERE password = '$password' AND email = '$email'";
    //$result = mysqli_query($conn,$sql);
        if($st==1)
        { 
	    $m="Successfully Authenticated!";
            echo "<script type='text/javascript'>alert('$m');window.location.href='db2adminrights.php';</script>";
	}
      else 
	{
	     $m1="Authentication Failed! Email and Password are not matching";
            echo "<script type='text/javascript'>alert('$m1');window.location.href='db2adminlogin.php';</script>";
	}
}
?>
<html>
<style type="text/css">
.topright{
position:absolute;
top:5px;
right:5px;
}
</style>
<div class="topright">
<form action="db2homepage.php" >
    <input type="submit" value="HOME" style="float: bottom;"/>
</form>
</div>
</html>
