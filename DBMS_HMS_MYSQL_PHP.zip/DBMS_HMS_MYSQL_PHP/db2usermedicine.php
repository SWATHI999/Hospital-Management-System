<!DOCTYPE>
   <html>
    <head>
    <title> Our Services</title>
    </head>
    <body>
    <center><h3><b>MEDICINES AVAILABLE FOR DISEASES</b></h3></center>
    <form name ="searchform" method="POST"  action="db2showmedicines.php">
    <?php
    $conn = mysqli_connect("localhost", "root",
    "1234", "HMS")
    or die("Cannot connect to database:" . 
    mysqli_connect_error($conn));
    echo "<select name= 'name'>";
    echo '<option value="">'.'Select'.'</option>';
    $query = mysqli_query($conn, "SELECT distinct treats FROM DOCTOR");


    while($row=mysqli_fetch_array($query))
    {
        echo "<option value='". $row['treats']."'>".$row['treats']
        .'</option>';

        }
        echo '</select>';
        ?> <input type="submit" name="submit" value="Submit"/>

</form>
        </html>
<html>
<style type="text/css">
.topright{
position:absolute;
top:5px;
right:5px;
}
</style>
<div class="topright">
<form action="db2homepage.php" >
    <input type="submit" value="LOGOUT" style="float: bottom;"/>
</form>
</div>
</html>


