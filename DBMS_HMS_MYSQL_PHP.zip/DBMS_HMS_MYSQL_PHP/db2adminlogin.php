<html>
<style type="text/css">
.topright{
position:absolute;
top:5px;
right:5px;
}
</style>
<body>
<h2><center><b><i>LOGIN</i></b></center></h2>
<form action="db2adminloginchecking.php" method="post">
<center>
<p>
<label for="email">Email</label>
<input type="text" id="email" name="email" placeholder="abc@example.com" maxlength="50" required/>
</p>
</center>
<center>
<p>
<label for="password">Password</label>
<input type="password" id="password" name="password" placeholder="Enter your password" maxlength="50" required/>
</p>
</center>
<center>
<p>
<input type="submit" name="login" value="Login"/>
</p>
</center>
</form>
</body>
<div class="topright">
<form action="db2homepage.php" >
    <input type="submit" value="HOME" style="float: left;"/>
</form>
</div>
</html>
