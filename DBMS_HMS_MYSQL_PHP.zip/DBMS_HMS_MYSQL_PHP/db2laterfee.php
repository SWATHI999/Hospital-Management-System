
<html>
<head>
<title>
Give Account Number
</title>

<script type="text/javascript">
    var datefield=document.createElement("input")
    datefield.setAttribute("type", "date")
    if (datefield.type!="date"){ //if browser doesn't support input type="date", load files for jQuery UI Date Picker
        document.write('<link href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/themes/base/jquery-ui.css" rel="stylesheet" type="text/css" />\n')
        document.write('<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4/jquery.min.js"><\/script>\n')
        document.write('<script src="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/jquery-ui.min.js"><\/script>\n') 
    }
</script>
 
<script>
if (datefield.type!="date"){ //if browser doesn't support input type="date", initialize date picker widget:
    jQuery(function($){ //on document.ready
        $('#birthday').datepicker();
    })
}
</script>
<script>
window.onload=function()
{
var myInput=document.getElementById('myInput');
myInput.onpaste=function(e)
{
e.preventDefault();
}
}
</script>

</head>
 
<center><h3><i><b>Give Valid details</b></i></h3></center>
<body>
<center>

<form action="db2bookinginsert1.php" method="post">
DOCTOR NAME:<input type="text" name="dnamel" placeholder="Enter"><br><br>
CONSULTATION DATE:<input type="date" name="cdl" id="birthday"><br><br>
<input type="submit" placeholder="Submit" value="Submit">
</form>

</center>
</body>
</html>
