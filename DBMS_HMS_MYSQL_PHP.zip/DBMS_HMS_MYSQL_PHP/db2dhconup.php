<?php
session_start();
?>
<?php
  $conn = mysqli_connect("localhost", "root",
    "1234", "HMS")
    or die("Cannot connect to database:" .
    mysqli_connect_error($conn));
$_SESSION['x1']=$_POST['name'];
?>
<html>
<head>
<title>
Update consultation fee
</title>
</head>
<center><h3><i><b>Update Consultation Fee</b></i></h3></center> 
<body>
<center>
<form method="post" action="db2dhconfeeup.php">
<input type="text" name="dhup" placeholder="Enter"><br><br>
<input type="submit" name="submit" value="submit"><br>
</form>
</center>
</body>
</html>
