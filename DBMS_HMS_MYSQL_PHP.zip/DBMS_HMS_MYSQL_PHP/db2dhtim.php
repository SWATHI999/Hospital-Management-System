<?php
session_start();
?>
<?php
  $conn = mysqli_connect("localhost", "root",
    "1234", "HMS")
    or die("Cannot connect to database:" .
    mysqli_connect_error($conn));
$_SESSION['x1']=$_POST['name'];
?>
<html>
<head>
<title>
Update consultation Timings
</title>
</head>
<center><h3><i><b>Update Consultation Timings</b></i></h3></center> 
<body>
<center>
<form method="post" action="db2dhdoctimup.php">
<input type="time" name="dhfromtime" placeholder="From Timing"><br><br>
<input type="time" name="dhtotime" placeholder="To Timing"><br><br>
<input type="submit" name="submit" value="submit"><br>
</form>
</center>
</body>
</html>
