<?php
session_start();
?>
<!DOCTYPE>
   <html>
    <head>
    <title> Our Services</title>
    </head>
    <body>
    <center><h3><b>Update</b></h3></center>
    <form name ="searchform" method="POST"  action="db2dhtim.php">
    <?php
    $conn = mysqli_connect("localhost", "root",
    "1234", "HMS")
    or die("Cannot connect to database:" . 
    mysqli_connect_error($conn));
	$x=$_SESSION['x'];
    echo "<select name= 'name'>";
    echo '<option value="">'.'Select'.'</option>';
    $query = mysqli_query($conn, "SELECT distinct name FROM DOCTOR where specialization='$x'");


    while($row=mysqli_fetch_array($query))
    {
        echo "<option value='". $row['name']."'>".$row['name']
        .'</option>';

        }
        echo '</select>';
        ?> <input type="submit" name="submit" value="Submit"/>

</form>
        </html>


