<html>
<center>
<br>
<h3><i><b> ENTER ACCOUNT NUMBER</b></i></h3>
<head>
<script>
window.onload=function()
{
var myInput=document.getElementById('myInput1');
myInput.onpaste=function(e)
{
e.preventDefault();
}
}
</script>
</head>
<body>
<form method="post" action="db2newlaterfee1.php">
ACCOUNT NUMBER:<input type="text" name="ac" placeholder="ACCOUNT NUMBER" id="myInput1" ><br><br>
<input type="submit" value="submit" name="submit">
</form> 
</body>
</center>
</html>

