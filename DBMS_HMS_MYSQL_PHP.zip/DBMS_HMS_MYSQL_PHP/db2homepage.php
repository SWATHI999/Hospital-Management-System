<html>
<head>
<title>
Our Services
</title>
</head>
<h3><i><b><center>HOSPITAL MANAGEMENT SYSTEM</center></b></i></h3><br>
<center>
<a href="db2adminlogin.php">ADMIN LOGIN</a><br><br>
<a href="db2dept_headlogin.php">DEPARTMENT HEAD LOGIN</a><br><br>
<a href="db2userlogin.php">USER LOGIN</a><br><br>
</center>
</html>
