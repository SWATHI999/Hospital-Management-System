<html>
<body oncopy="return false;" onpaste="return false;" oncut="return false;">
<?php
$servername = "localhost";
$username = "root";
$password = "1234";
$dbname = "HMS";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
//header("Refresh:3;url=http://localhost/db2showmedicines.php");
$s1=$_POST['name'];

$result = mysqli_query($conn,"select * from medicine_view where treats='$s1'");

echo "<center><h3>Available medicines for $s1 disease</h3></center>";

echo "<table border='1'>
<tr>
<th>Doctor Name</th>
<th>Specialization</th>
<th>Medicine Name</th>
<th>Quantity</th>
<th>Price</th>
<th>Expiry_date</th>
</tr>";
while($row = mysqli_fetch_array($result))
{
echo "<tr>";

echo "<td>" . $row['doctor_name'] . "</td>";
echo "<td>" . $row['specialization'] . "</td>";
echo "<td>" . $row['medicine_name'] . "</td>";
echo "<td>" . $row['quantity'] . "</td>";
echo "<td>" . $row['price'] . "</td>";
echo "<td>" . $row['expiry_date'] . "</td>";

echo "</tr>";
}
echo "</table>";
$conn->close();
?>

<html>
<style type="text/css">
.topright{
position:absolute;
top:5px;
right:5px;
}
</style>
<script>
document.oncontextmenu=new Function("return false");
document.onselectstart=new Function("return false");
if(window.sidebar){
document.onmousedown=new Function("return false");
document.onclick=new Function("return true");
document.oncut=new Function("return false");
document.oncopy=new Function("return false");
document.onpaste=new Function("return false");
}
</script>
<script>

//location.reload(true);
setTimeout(function()
{
window.location.reload(1);
},10000);

</script>

<!--<script type="text/javascript" src="http://ajax.googleapis.com/ajax/
libs/jquery/1.3.0/jquery.min.js"></script>
<script type="text/javascript">
var auto_refresh = setInterval(
function ()
{
$('#load_tweets').load('db2showmedicines.php').fadeIn("fast");
}, 10000); // refresh every 10000 milliseconds

<body>
<div id="load_tweets"> </div>
</body>

</script>--->






<div class="topright">
<form action="db2homepage.php" >
    <input type="submit" value="LOGOUT" style="float: bottom;"/>
</form>
</div>
</html>
<br>
<html>
<a href="db2buymedicine.php">Want to purchase</a>
</html>
</body>
</html>
