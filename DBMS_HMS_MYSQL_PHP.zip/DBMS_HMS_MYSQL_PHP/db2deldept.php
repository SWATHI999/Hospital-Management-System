<head>
<title>
Give Details
</title>
</head>
<center><h3><i><b>DELETE DEPARTMENT HEAD</b></i></h3></center>

<form action="db2adddept1.php" method="post">

<center>
<INPUT type = "text" name="dname" placeholder="Enter dept_name" required><br><br>
<INPUT type = "text" name="demail" placeholder="abc@gmail.com" required><br><br>



<INPUT type = "Submit" name = "Submit1" value = "Submit">
</center>

</form>
<html>
<style type="text/css">
.topright{
position:absolute;
top:5px;
right:5px;
}
</style>
<div class="topright">
<form action="db2adminrights.php" >
    <input type="submit" value="<<BACK" style="float: bottom;"/>
</form>
</div>
</html>
