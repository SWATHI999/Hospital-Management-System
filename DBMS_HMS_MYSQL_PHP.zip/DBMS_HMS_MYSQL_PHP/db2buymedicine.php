<?php
session_start();
?>
 <?php
if($_SERVER["REQUEST_METHOD"]=="POST")
{

  $conn = mysqli_connect("localhost", "root",
    "1234", "HMS")
    or die("Cannot connect to database:" .
    mysqli_connect_error($conn));
$c=$_POST['mname'];
$c1=$_POST['quantity'];
$c3=$_POST['ac'];
$s3=$_SESSION['uemail'];
echo $s3;

$result = mysqli_query($conn,"select * from medicine m where m.name='$c'");

while($row = mysqli_fetch_array($result))
{
$x=$row['id'];
$xx=$row['price'];
}
$xxx=$xx*$c1;

$result1 = mysqli_query($conn,"call medicine_procedure('$c3','$s3','$xxx','$c1','$x',@status,@bal)");

$result4=mysqli_query($conn,"select @status,@bal");

if(mysqli_num_rows($result4)==1)
{
while($row4 = mysqli_fetch_array($result4))
{
$x5=$row4['@status'];
echo "$x5";
$x6=$row4['@bal'];
$xs=(string)$x6;
}

$m1="YOUR TRANSACTION IS";
$m3="YOUR CURRENT BALANCE IS";

echo "<script type='text/javascript'>alert('$m1'+ '$x5' +'$m3'+ '$xs');window.location.href='db2usersubmitdetails.php';</script>";
#"<script type='text/javascript'>alert('$m');window.location.href='db2usersubmitdetails.php';</script>";
}
mysqli_close($conn);
}
?>

<html>
<center>
<form action="db2buymedicine.php" method="POST">
<center><h3><i><b>BUY MEDICINE</b></i></h3></center>
MEDICINE NAME:<input type="text" id="myInput" name="mname" placeholder="Enter"><br><br>
QUANTITY REQUIRED:<input type="text" name="quantity" placeholder="Enter">
<br><br>
ACCOUNT NUMBER:<input type="text" name="ac" id="myInput1" placeholder="Enter"><br><br>
<input type="Submit" value="submit" name="submit"><br>
</form>
</center>
<head>
<script>
window.onload=function()
{
var myInput=document.getElementById('myInput');
myInput.onpaste=function(e)
{
e.preventDefault();
}
}
</script>
<script>
window.onload=function()
{
var myInput=document.getElementById('myInput1');
myInput.onpaste=function(e)
{
e.preventDefault();
}
}
</script>
</head>
</html>
<html>
<style type="text/css">
.topright{
position:absolute;
top:5px;
right:5px;
}
</style>
<div class="topright">
<form action="db2homepage.php" >
    <input type="submit" value="LOGOUT" style="float: bottom;"/>
</form>
</div>
</html>
