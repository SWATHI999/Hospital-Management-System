<?php
session_start();
?>
<?php
 $conn = mysqli_connect("localhost", "root",
    "1234", "HMS")
    or die("Cannot connect to database:" . 
    mysqli_connect_error($conn));

$x=$_SESSION['s'];
//echo "$x";
$x1=$_POST['hname'];
$x2=$_POST['hage'];
$x3=$_POST['hexp'];
$x4=$_POST['had'];
$x5=$_POST['hgender'];
$x6=$_POST['hph'];
$x7=$_POST['hemail'];
$x8=$_POST['hpwd'];
$x9=$_POST['dname'];
$x10=$_POST['demail'];
$x11=$_POST['dtad'];
$x12=$_POST['dtph'];
$x13=$_POST['dtemail'];

$result1 = mysqli_query($conn,"insert into head(dept_name,name,age,gender,experience,phone_number,address,email,password) values('$x','$x1','$x2','$x5','$x3','$x6','$x4','$x7','$x8')");


$result2=mysqli_query($conn,"delete from head where dept_name='$x9' and email='$x10'");

$result3=mysqli_query($conn,"update head set address='$x11',phone_number='$x12' where email='$x13'");

mysqli_close($conn);
?>
