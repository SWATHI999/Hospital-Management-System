<?php
$servername = "localhost";
$username = "root";
$password = "1234";
$dbname = "HMS";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$result = mysqli_query($conn,"select * from DOCTOR");

echo "<center><h3>Available DOCTORS </h3></center>";

echo "<table border='1'>
<tr>
<th>Doctor Name</th>
<th>Specialization</th>
<th>Experience</th>
<th>From Timings</th>
<th>To Timings</th>
<th>Consultation Fee</th>
<th>Edit</th>
</tr>";
while($row = mysqli_fetch_array($result))
{
echo "<tr>";

echo "<td>" . $row['name'] . "</td>";
echo "<td>" . $row['specialization'] . "</td>";
echo "<td>" . $row['experience'] . "</td>";
echo "<td>" . $row['from_timings'] . "</td>";
echo "<td>" . $row['to_timings'] . "</td>";
echo "<td>" . $row['consultation_fee'] . "</td>";
echo "<td>"."<a href='db2fake.php'>Change</a>"."</td>";
echo "</tr>";
}
echo "</table>";
$conn->close();
?>
<html>
<style type="text/css">
.topright{
position:absolute;
top:5px;
right:5px;
}
</style>
<div class="topright">
<form action="db2homepage.php" >
    <input type="submit" value="LOGOUT" style="float: bottom;"/>
</form>
</div>
</html>





