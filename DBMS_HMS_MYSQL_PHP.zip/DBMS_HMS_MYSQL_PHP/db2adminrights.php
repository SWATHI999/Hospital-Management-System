<html>
<head>
<title>
Admin Rights
</title>
</head>
<center><h3><i><b>Admin Rights</b></i></h3></center>
<body>
<center>
<a href="db2adddept.php">Add Department Head</a><br><br>
<a href="db2deldept.php">Delete Department Head</a><br><br>
<a href="db2updept.php">Update Department Head Details</a><br><br>
<a href="db2nurse.php">Update Nurse Salary</a><br><br>
</center>
</body>
</html>
<html>
<style type="text/css">
.topright{
position:absolute;
top:5px;
right:5px;
}
</style>
<div class="topright">
<form action="db2homepage.php" >
    <input type="submit" value="LOGOUT" style="float: bottom;"/>
</form>
</div>
</html>
