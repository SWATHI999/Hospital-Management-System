<?php
session_start();
?>
<?php
$servername = "localhost";
$username = "root";
$password = "1234";
$dbname = "HMS";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$x=$_SESSION['x'];

$x2=$_SESSION['x1'];

$y=$_POST['dhfromtime'];

$y1=$_POST['dhtotime'];


$result1 = mysqli_query($conn,"call update_consultation_timing('$x','$x1','$y','$y1',@status)");
$result2=mysqli_query($conn,"select @status");

if(mysqli_num_rows($result2)==1)
{
while($row4 = mysqli_fetch_array($result2))
{
$x5=$row4['@status'];
echo "$x5";
}
}
mysqli_close($conn);
?>
