<html>
<style type="text/css">
.topright{
position:absolute;
top:5px;
right:5px;
}
</style>
<head>
<title>
Give Details
</title>
</head>
<center><h3><i><b>REGISTRATION FORM</b></i></h3></center>

<form action="db2usersubmitdetails.php" method="post">

<center>
<INPUT type = "text" name="uname" placeholder="Enter name" required><br><br>
<INPUT type = "text" name="uage" placeholder="Enter age" required><br><br>

Gender:<INPUT type = "radio" name="ugender" value="Male" checked>Male
<INPUT type = "radio" name="ugender" value="Female">Female<br><br>
<INPUT type = "text" name="uemail" placeholder="abc@example.com" required><br><br>
<INPUT type = "password" name="upwd" placeholder="Enter Password" required><br><br>
<INPUT type = "text" name="uad" placeholder="Enter Address" required><br><br>
<INPUT type = "text" name="uph"  placeholder="Phone number" required><br><br>
<INPUT type = "Submit" name = "Submit1" value = "Submit">
</center>

</form>
<div class="topright">
<form action="db2homepage.php" >
    <input type="submit" value="HOME" style="float: left,bottom;"/>
</form>
</div>
</html>
