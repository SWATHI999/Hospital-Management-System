<!DOCTYPE>
   <html>
    <head>
    <title> Our Services</title>
    </head>
    <body>
    <center><h3><b>Update Nurse Salary</b></h3></center>
    <form name ="searchform" method="POST"  action="db2nurseadmin.php">
    <?php
    $conn = mysqli_connect("localhost", "root",
    "1234", "HMS")
    or die("Cannot connect to database:" . 
    mysqli_connect_error($conn));
    echo "<select name= 'name'>";
    echo '<option value="">'.'Select'.'</option>';
    $query = mysqli_query($conn, "SELECT distinct department FROM nurse_update1");


    while($row=mysqli_fetch_array($query))
    {
        echo "<option value='". $row['department']."'>".$row['department']
        .'</option>';

        }
        echo '</select>';
        ?>
<br><br><input type="text" name="nn" placeholder="Enter Nurse Name"><br><br>
<input type="text" name="nsal" placeholder="Salary"><br><br>
 <input type="submit" name="submit" value="Submit"/>

</form>
        </html>
<html>
<style type="text/css">
.topright{
position:absolute;
top:5px;
right:5px;
}
</style>
<div class="topright">
<form action="db2adminrights.php" >
    <input type="submit" value="<<BACK" style="float: bottom;"/>
</form>
</div>
</html>


