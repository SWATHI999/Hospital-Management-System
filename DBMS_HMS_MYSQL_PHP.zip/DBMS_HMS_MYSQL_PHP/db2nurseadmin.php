
 <?php
  $conn = mysqli_connect("localhost", "root",
    "1234", "HMS")
    or die("Cannot connect to database:" .
    mysqli_connect_error($conn));
$c=$_POST['name'];
$c1=$_POST['nn'];
$c3=$_POST['nsal'];
$result1 = mysqli_query($conn,"call nurse_update('$c','$c1','$c3')");
mysqli_close($conn);
?>


