<html>
<style type="text/css">
.topright{
position:absolute;
top:5px;
right:5px;
}
</style>
<center>
<h3><i><b>REGISTER OR LOGIN</b></i></h3><br></center>
<center>
<a href="db2usersignup.php">SIGN UP</a><br><br>
<a href="db2registereduserlogin.php">LOGIN</a><br><br>
</center>

<div class="topright">
<form action="db2homepage.php" >
    <input type="submit" value="HOME" style="float: bottom;"/>
</form>
</div>
</html>
