<?php
session_start();
?>
 <?php
  $conn = mysqli_connect("localhost", "root",
    "1234", "HMS")
    or die("Cannot connect to database:" .
    mysqli_connect_error($conn));
$c1=$_POST['dname'];
$c2=$_POST['cd'];
if ('$c2'<'NOW()')
echo "Give valid date";
$c3=$_POST['acn'];
$s3=$_SESSION['uemail'];
echo $s3;

$result = mysqli_query($conn,"select * from DOCTOR d where d.name='$c1'");

while($row = mysqli_fetch_array($result))
{
$x=$row['id'];
$x4=$row['consultation_fee'];
}

$result1 = mysqli_query($conn,"select * from users u where u.email='$s3'");

while($row1 = mysqli_fetch_array($result1))
{
$x1=$row1['phone_number'];
$x2=$row1['name'];
}

#echo "<center><h3> $c1 </h3></center>";

$result1 = mysqli_query($conn,"insert into bookings(doctor_id,user_name,date_of_consultation,phone_number,fee_status ) values('$x','$x2','$c2','$x1','Yes')");

$result3=mysqli_query($conn,"call consult_trans1('$c3','$s3','$x4',@status,@bal)");
$result4=mysqli_query($conn,"select @status,@bal");

if(mysqli_num_rows($result4)==1)
{
while($row4 = mysqli_fetch_array($result4))
{
$x5=$row4['@status'];
echo "$x5";
$x6=$row4['@bal'];
$xs=(string)$x6;
}

$m1="YOUR TRANSACTION IS";
$m3="YOUR CURRENT BALANCE IS";

echo "<script type='text/javascript'>alert('$m1'+ '$x5' +'$m3'+ '$xs');window.location.href='db2usersubmitdetails.php';</script>";
#"<script type='text/javascript'>alert('$m');window.location.href='db2usersubmitdetails.php';</script>";
}
mysqli_close($conn);
?>

