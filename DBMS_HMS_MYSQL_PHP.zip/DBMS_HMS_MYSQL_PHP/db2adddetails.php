<?php
session_start();
?>
<html>
<style type="text/css">
.topright{
position:absolute;
top:5px;
right:5px;
}
</style>
<head>
<title>
Give Details
</title>
</head>
<center><h3><i><b>FILL DETAILS</b></i></h3></center>

<form action="db2adddept1.php" method="post">

<center>
<INPUT type = "text" name="hname" placeholder="Enter name" required><br><br>
<INPUT type = "text" name="hage" placeholder="Enter age" required><br><br>

Gender:<INPUT type = "radio" name="hgender" value="Male" checked>Male
<INPUT type = "radio" name="hgender" value="Female">Female<br><br>
<INPUT type = "text" name="had" placeholder="Enter Address" required><br><br>
<INPUT type = "text" name="hph"  placeholder="Phone number" required><br><br>
<INPUT type = "text" name="hexp" placeholder="Enter" required><br><br>
<INPUT type = "text" name="hemail" placeholder="abc@example.com" required><br><br>
<INPUT type = "password" name="hpwd" placeholder="Enter Password" required><br><br>

<INPUT type = "Submit" name = "Submit1" value = "Submit">
</center>

</form>
<div class="topright">
<form action="db2adminrights.php" >
    <input type="submit" value="<<BACK" style="float: left,bottom;"/>
</form>
</div>
</html>
<?php
 $conn = mysqli_connect("localhost", "root",
    "1234", "HMS")
    or die("Cannot connect to database:" . 
    mysqli_connect_error($conn));
$_SESSION['s']=$_POST['name'];


mysqli_close($conn);
?>
