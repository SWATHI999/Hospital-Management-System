<?php
session_start();
?>
<html>
<head>
<script>
document.oncontextmenu=new Function("return false");
document.onselectstart=new Function("return false");
if(window.sidebar){
document.onmousedown=new Function("return false");
document.onclick=new Function("return true");
document.oncut=new Function("return false");
document.oncopy=new Function("return false");
document.onpaste=new Function("return false");
}
</script>
</head>
<body oncopy="return false;" onpaste="return false;" oncut="return false;">


 <?php
  $conn = mysqli_connect("localhost", "root",
    "1234", "HMS")
    or die("Cannot connect to database:" .
    mysqli_connect_error($conn));
$c=$_POST['name'];
$_SESSION['s1']=$c;
#echo "$c";

$result = mysqli_query($conn,"select d.name,d.age,d.gender,d.specialization,d.experience,d.consultation_fee,d.from_timings,d.to_timings from DOCTOR d where d.treats='$c'");

echo "<center><h3>Available Doctors for $c disease</h3></center>";

echo "<table border='1'>
<tr>
<th>Doctor Name</th>
<th>Age</th>
<th>Gender</th>
<th>Specialization</th>
<th>Experience</th>
<th>Consultation Fee</th>
<th>From_timings</th>
<th>To_Timings</th>
</tr>";
while($row = mysqli_fetch_array($result))
{
echo "<tr>";

echo "<td>" . $row['name'] . "</td>";
echo "<td>" . $row['age'] . "</td>";
echo "<td>" . $row['gender'] . "</td>";
echo "<td>" . $row['specialization'] . "</td>";
echo "<td>" . $row['experience'] . "</td>";
echo "<td>" . $row['consultation_fee'] . "</td>";
echo "<td>" . $row['from_timings'] . "</td>";
echo "<td>" . $row['to_timings'] . "</td>";

echo "</tr>";
}
echo "</table>";

mysqli_close($con);
?>
<html>
<br><br>Pay Consultation Fee :</html>
<?php
echo '<input type="radio" name="ul" value= "NOW" onclick="location.href=\'db2nowfee.php\'"/>NOW';

echo '<input type="radio" name="ul1" value= "LATER" onclick="location.href=\'db2laterfee.php\'"/>LATER';
?>

</body></html>
<html>
<style type="text/css">
.topright{
position:absolute;
top:5px;
right:5px;
}
</style>
<div class="topright">
<form action="db2homepage.php" >
    <input type="submit" value="LOGOUT" style="float: bottom;"/>
</form>
</div>
</html>
