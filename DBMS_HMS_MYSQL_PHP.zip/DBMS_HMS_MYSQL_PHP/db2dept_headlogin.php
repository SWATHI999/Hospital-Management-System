<html>
<head>
<title>
Department Head Rights
</title>
</head>
<center><h3><i><b>CHOOSE THE DEPARTMENT</b><i></h3></center>
<body>
<center>
<!--<a href="wildcard.php?p=A">-->
<a href="db2dhcl.php?P=CARDIOLOGY">CARDIOLOGY</a><br><br>
<a href="db2dhcl.php?P=NEUROLOGY">NEUROLOGY</a><br><br>
<a href="db2dhcl.php?P=PSYCHOLOGY">PSYCHOLOGY</a><br><br>
<a href="db2dhcl.php?P=DERMATOLOGY">DERMATOLOGY</a><br><br>
<a href="db2dhcl.php?P=GYNECOLOGY">GYNECOLOGY</a><br><br>
</center>
</body>
</html>
<html>
<style type="text/css">
.topright{
position:absolute;
top:5px;
right:5px;
}
</style>
<div class="topright">
<form action="db2homepage.php" >
    <input type="submit" value="HOME" style="float: bottom;"/>
</form>
</div>
</html>

