<?php
session_start();
?>

<?php
  $conn = mysqli_connect("localhost", "root",
    "1234", "HMS")
    or die("Cannot connect to database:" .
    mysqli_connect_error($conn));

   /* if(check_login()) {
  echo 'You are in!';
} else {
    header('Location: registereduserlogin.php');
    exit;
}

function check_login () {
    if(isset($_SESSION['uemail'] && $_SESSION['uemail'] != '') {
       return true;
    } else {
       false;
    }
}*/


if(!empty($_POST['password']) && !empty($_POST['email']))
{
    $email = $_POST['email'];
    $password = $_POST['password'];
    $_SESSION['uemail']=$_POST['email'];
     print_r($_SESSION);



    $sql = "SELECT * FROM users WHERE password = '$password' AND email = '$email'";
    $result = mysqli_query($conn,$sql);
        if(mysqli_num_rows($result)==1)
        { 
	    $m="Successfully Authenticated!";
            echo "<script type='text/javascript'>alert('$m');window.location.href='db2usersubmitdetails.php';</script>";
	}
      else 
	{
	     $m1="Authentication Failed!";
            echo "<script type='text/javascript'>alert('$m1');window.location.href='db2userlogin.php';</script>";
	}
}
?>
<html>
<style type="text/css">
.topright{
position:absolute;
top:5px;
right:5px;
}
</style>
<div class="topright">
<form action="db2homepage.php" >
    <input type="submit" value="HOME" style="float: bottom;"/>
</form>
</div>
</html>
