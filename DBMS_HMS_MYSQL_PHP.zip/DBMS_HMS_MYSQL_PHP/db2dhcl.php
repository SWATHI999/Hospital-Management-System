<?php
session_start();
?>
<html>
<body>
<center><h3><i><b>Give valid details</b></i></h3></center>
<form action="db2sample.php" method="post">
<center>
<p>
<label for="email">Email</label>
<input type="text" id="email" name="email" placeholder="abc@example.com" maxlength="50" required/>
</p>
</center>
<center>
<p>
<label for="password">Password</label>
<input type="password" id="password" name="password" placeholder="Enter your password" maxlength="50" required/>
</p>
</center>
<center>
<p>
<input type="submit" name="login" value="Login"/>
</p>
</center>
</form>
</body>
</html>
<?php
  $conn = mysqli_connect("localhost", "root",
    "1234", "HMS")
    or die("Cannot connect to database:" .
    mysqli_connect_error($conn));
$_SESSION['x']=(string)$_GET['P'];
?>
<html>
<style type="text/css">
.topright{
position:absolute;
top:5px;
right:5px;
}
</style>
<div class="topright">
<form action="db2homepage.php" >
    <input type="submit" value="LOGOUT" style="float: bottom;"/>
</form>
</div>
</html>

