<?php
session_start();
?>
 <?php
  $conn = mysqli_connect("localhost", "root",
    "1234", "HMS")
    or die("Cannot connect to database:" .
    mysqli_connect_error($conn));

$c3=$_POST['ac'];
$s3=$_SESSION['uemail'];
$c4=$_SESSION['s'];
$c5=$_SESSION['s1'];

echo $s3;
echo $c3;
echo $c4;
echo $c5;

$result3=mysqli_query($conn,"call later_fee1('$c4','$c5','$s3','$c3',@bal)");
$result4=mysqli_query($conn,"select @bal");

if(mysqli_num_rows($result4)==1)
{
while($row4 = mysqli_fetch_array($result4))
{
$x6=$row4['@bal'];
$xs=(string)$x6;
}

$m3="YOUR CURRENT BALANCE IS";

echo "<script type='text/javascript'>alert('$m3'+ '$xs');window.location.href='db2usersubmitdetails.php';</script>";
#"<script type='text/javascript'>alert('$m');window.location.href='db2usersubmitdetails.php';</script>";
}
mysqli_close($conn);
?>

